﻿namespace AOSharp.Core.UI.Options
{
    public abstract class MenuItem : MenuComponent
    {
        public MenuItem(string name, string displayName) : base(name, displayName)
        {
        }
    }
}
