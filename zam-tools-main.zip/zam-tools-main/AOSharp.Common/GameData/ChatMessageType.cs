﻿namespace AOSharp.Common.GameData
{
    public enum ChatRange: byte
    {
        Say = 0x00,
        Whisper = 0x01,
        Shout = 0x02
    }
}