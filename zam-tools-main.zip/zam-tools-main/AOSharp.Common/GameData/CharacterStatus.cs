﻿namespace AOSharp.Common.GameData
{
    public enum CharacterStatus
    {
        Active = 0x00000001
    }
}
